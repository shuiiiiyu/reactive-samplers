#!/usr/bin/env bash
# CPU control-flow checks only. Run this inside a detached tmux session on RunPod.
set -uo pipefail
cd "$(dirname "$0")/.."
mkdir -p artifacts/logs
uv run --no-project python -m unittest discover -s tests -v > artifacts/logs/framework-check.log 2>&1
status=$?
printf '%s\n' "$status" > artifacts/logs/framework-check.exit-code
exit "$status"
