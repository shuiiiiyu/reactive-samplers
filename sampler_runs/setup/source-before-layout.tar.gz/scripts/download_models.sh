#!/usr/bin/env bash
# Start inside tmux so downloads survive the SSH/desktop session.
set -uo pipefail
cd "$(dirname "$0")/.."
mkdir -p artifacts/logs
uv run --no-project --with huggingface-hub==0.34.4 python scripts/download_models.py --model both \
  > artifacts/logs/model-download.log 2>&1
status=$?
printf '%s\n' "$status" > artifacts/logs/model-download.exit-code
exit "$status"
