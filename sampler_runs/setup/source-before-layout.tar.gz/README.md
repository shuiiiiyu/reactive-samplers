# Reactive Samplers

An initial research framework for **Agent-Driven Adaptive Diffusion Sampling**.
It follows OPAL's division into a sampler wrapper, editable programs, agent sessions,
decision schedules and versioned run records. This is our own timestep-only method;
TPDM, AYS and OYS remain separate, unimplemented baselines.

## What is implemented

- Per-image sampling control with continuous, strictly decreasing **physical sigma** actions.
- Agent checks at every executed step or fixed zero-based executed-step indices.
- A synchronous checkpoint: after the current prediction, before the latent update.
  A trusted agent bridge may edit/run analysis repeatedly before returning.
- Same-image hot reload of both programs, complete source versions, relative helper imports,
  invalid-edit rejection and fallback before applying a candidate's invalid action.
- Raw current/past latent, predictions, optional named-layer captures and per-image memory.
- Frozen strategy export with a source hash; evaluation disables the agent path.
- SD3-Medium adapter using the official Diffusers FlowMatch Euler step, CFG and VAE.
- One shared Hydra entry for default, exploration and frozen evaluation.
- Prompt/seed manifest validation; actual NFE, CFG batch items, elapsed times and optional quality scorers.

**This is a scaffold, not an experimentally validated acceleration method.** Real Agent
credentials/bridge, SD3 checkpoints, benchmark manifests and quality weights are not configured.
The initial policy simply follows the reference schedule. There are no fabricated results.

## Layout

```
reactive_samplers/
  wrapper.py         sampling / check / reload / action / update
  context.py         open observation context and sigma Action
  programs.py        workspace source loading, versions and freeze
  agent.py           paused state and diagnostic request lifecycle
  backends/          keep fixture and trusted external-command bridge
  schedule.py        every-step and checkpoint Agent intervention
  models/sd3.py      original model inference and numerical-step adapter
  defaults/         initial analysis.py and updater.py
  prompts/          Agent protocol
  evaluation.py     explicit HPSv2.1 / CLIPScore adapters
  report.py         events and summaries
conf/               Hydra configuration (required values remain ???)
scripts/            shared entry and checks
experiments/main/   exploration/evaluation manifest contract
baselines/          future TPDM / AYS / OYS
benchmarks/         future official benchmark integration
preliminary_latex/ reference-source placeholder required by parent workspace
```

## Setup and CPU checks

Use uv; no model or Agent is needed for core tests:

```bash
uv run --no-project python -m unittest discover -s tests -v
```

The official-scheduler parity test is skipped if torch/diffusers are unavailable.
Tests use a scalar transport fixture; this is not a diffusion benchmark or quality result.

`scripts/check_environment.sh` installs the small core environment with uv, checks the CLI
and Hydra configuration, and uses an isolated Diffusers tool environment plus existing system
torch to run official scheduler parity without fetching a second torch/CUDA installation.
Run this check inside tmux; logs go to artifacts/logs/environment-check.log.

For a future dedicated SD3 environment (installs packages; does not fetch model weights):

```bash
uv sync --extra sd3
uv run reactive-samplers --help
uv run python -m unittest discover -s tests -v
```

The first SD3 adapter is pinned to **diffusers 0.35.1**. Before real experiments run the
full pipeline parity script with the actual checkpoint and chosen inference configuration.
Do not substitute a toy/core test for that gate. No global Python installation is modified.

## Main experiment configuration

`conf/sd3_main.yaml` leaves model/device/precision/size/CFG/steps/paths explicitly required.
These were not chosen by the user yet. Inspect the configuration without generating images:

```bash
uv run python scripts/run_main.py --cfg job
```

Prompt files contain one JSON object per line with `id`, `prompt`, integer `seed`,
and optionally `source`. IDs must be filename-safe and unique. The first plan uses
10 exploration rows and 40 disjoint evaluation rows. No examples are prefilled as COCO/HPD.
Check prompt text overlap as well as IDs when constructing these manifests.

Choose mode `default`, `explore` or `evaluate` using Hydra overrides. Evaluation requires
`policy` pointing to a frozen package with manifest.json. Exploration requires an explicitly
configured command bridge; it cannot silently substitute a no-op Agent. Full generation
commands should only be launched after model paths, parameters, tracking and credentials
have been resolved. Use tmux for durable remote checks and future generation jobs.

## Local inference weights

`scripts/download_models.sh` downloads official default safetensors components for SD3-Medium
and SDXL Base 1.0 into `artifacts/models/`, under a detached tmux session. No duplicate fp16
variants, ONNX weights, pickle weights or root-level single-file checkpoints are downloaded.
Exact upstream revisions, selected files and status are recorded in download-status.json.
The local directories are `artifacts/models/sd3-medium` and `artifacts/models/sdxl-base-1.0`.
Inference loading uses local_files_only=True. Do not hardcode these server-specific absolute
paths into the shared configuration before choosing an experiment.

SD3 is gated: obtain access on its Hugging Face model page and log in on the server using
`uv run --no-project --with huggingface-hub==0.34.4 hf auth login`. Never put a token in a
tracked config. Retry SD3 alone with `uv run --no-project --with huggingface-hub==0.34.4
python scripts/download_models.py --model sd3-medium`. Downloads are resumable.

## Agent bridge and repeated within-step inspection

`agent.command` is an argv list for a trusted bridge, with `{request}` and `{workspace}`
placeholders. It is executed without shell interpolation. The JSON request includes a stable
session_id, current state snapshot, editable directory, previous-image feedback and protocol.
The bridge must resume its own provider/CLI conversation using this id. Provider-specific
authentication/session handling is deliberately not guessed in this scaffold.

During a check the bridge/Agent can run the `inspect_command` in the request repeatedly:

```bash
reactive-samplers inspect /path/to/state.pt --workspace /path/to/workspace
```

Each invocation loads the latest analysis and its relative helpers against the SAME paused
state, using a copy of pre-analysis memory. Snapshots are CPU copies; diagnostic-only GPU
work or extra model replay requires a later explicit tool integration. Inspect does not
advance the sampler. When the bridge returns, the framework reloads the strategy, reruns
analysis and validates its action before the official scheduler update.

`FEATURE_LAYERS` can request arbitrary transformer named_modules outputs on subsequent
forwards. Existing captured raw history can be reanalyzed. Uncaptured past features cannot
be obtained retrospectively. Extra VAE/VLM replay tools are NOT implemented in this scaffold.
Frozen inference retains `HISTORY_LIMIT` past steps (initially 2; None requests full history).
Exploration retains the full raw trajectory. Agent diagnostic state resets per image.

## Numerical boundary

Actions use physical sigma **after** the scheduler's shift. The adapter sets the current/next
sigma boundary pair and calls the unmodified official `scheduler.step()`. It does not call
`set_timesteps()` again on already-shifted actions. This uses scheduler internal arrays/index
state and is intentionally version-pinned; it needs pipeline parity before deployment.

Supported: a single image at a time, deterministic descending FlowMatch Euler, standard
SD3-Medium text-to-image with fixed CFG. LoRA/IP-Adapter, SLG, custom attention kwargs,
stochastic/inverted flow, SDXL and multi-GPU inference are outside the initial adapter.
CPU/GPU offload and compiled execution have not been validated.

## Records and timing semantics

Each fresh output directory contains config/environment/prompts, workspace/programs,
decisions (state/request/answer/timing), per-image trajectories, images, feedback and results.
Each actual step records sigma boundaries and the strategy source hash. Explicit freeze:

```bash
reactive-samplers freeze runs/explore/programs/COMMITTED_HASH artifacts/frozen_policy
reactive-samplers report runs/evaluation
```

Use the committed version, not pending workspace edits, for exports. `scratch/` Python files
are excluded. Source hashes are integrity checks, not a malicious-code security sandbox.
Observation/updater programs must not mutate model inputs or perform hidden model calls.

NFE counts denoiser invocations; denoiser_items also records CFG batch items (2 per call
when CFG is enabled). sampling_seconds includes prediction/observation/actions/updates and
Agent/checkpoint overhead. end_to_end_seconds additionally includes prompt encoding and VAE
decoding, but excludes model loading, image-file writing and quality scoring. agent_seconds
measures bridge-process duration; subtracting it does not remove all diagnostic overhead.
Compare genuine no-Agent evaluation times for deployment speed claims. GPU timing synchronizes
at measurement boundaries. Warmup/repeated timing, quality comparisons, tracking and official
benchmark protocols still need experiment-level setup before paper claims.

HPS/CLIP metrics are opt-in and may fetch their evaluator weights when explicitly used.
With metrics.names=[] output is marked quality_status=not_configured. It is NOT evidence of
quality preservation. FID is intentionally absent from the small-scale feedback path.

## References

- OPAL: https://github.com/xingjian-bai/opal
- Diffusers: https://github.com/huggingface/diffusers/tree/v0.35.1
- TPDM: https://github.com/maple-research-lab/TPDM
- AYS: https://proceedings.mlr.press/v235/sabour24a.html
- OYS: https://arxiv.org/abs/2608.18040
