# Reactive Samplers

Implement the user's Agent-Driven Adaptive Diffusion Sampling project.
Current scope: SD3-Medium, official FlowMatch Euler, main small-scale experiment.
Reference organization: https://github.com/xingjian-bai/opal (organization/mechanism only).

- Freeze model weights. Do not train a timestep predictor or change the solver formula,
  CFG, caching, model architecture, precision, data or evaluation to improve results.
- The Agent can modify analysis.py and updater.py during ONE image's sampling.
  Support repeated diagnostic calls at a paused step, every-step and fixed-checkpoint checks.
- Exploration plan: 10 images; evaluation plan: 40 disjoint images with one frozen policy.
  Do not fill these manifests with invented benchmark examples.
- Final inference makes no LLM calls. Per-image memory resets; strategy source persists.
- Preserve the original scheduler's shifted-sigma semantics and numeric operations.
- Never claim acceleration or quality preservation without real measurement.
- SDXL, TPDM, AYS, OYS and full benchmarks are placeholders for this scaffold.
- Use uv for dependency management, Hydra YAML for experiments, and tmux for durable
  remote checks/jobs. Do not launch GPU generation or paid agents merely to test the scaffold.
- Core tests: `uv run --no-project python -m unittest discover -s tests -v`.
- Parent DeepResearch instructions apply. The user explicitly authorized scaffolding despite
  missing parent memory/project.md and memory/sue/SCALE_UP.md in this checkout.
