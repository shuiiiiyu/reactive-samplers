"""Agent backends for local commands and the remote mailbox bridge."""
import json
import subprocess
import time
from pathlib import Path


class KeepAgent:
    def __call__(self, request_path, workspace):
        return "keep"


class CommandAgent:
    def __init__(self, argv):
        if not argv or not isinstance(argv, list) or not all(isinstance(x, str) for x in argv):
            raise ValueError("agent.command must be a nonempty argument list")
        self.argv = argv

    def __call__(self, request_path, workspace):
        # The bridge owns CLI/provider session resumption. No shell interpolation.
        result = subprocess.run(
            [s.replace("{request}", str(request_path)).replace("{workspace}", str(workspace)) for s in self.argv],
            cwd=workspace, text=True, capture_output=True, check=True,
        )
        return result.stdout


class MailboxAgent:
    """Wait for a remote coding agent and serve same-step analysis requests."""
    def __init__(self, timeout_seconds=900, poll_seconds=1):
        if timeout_seconds <= 0 or poll_seconds <= 0:
            raise ValueError("Mailbox timeout and poll interval must be positive")
        self.timeout_seconds, self.poll_seconds = timeout_seconds, poll_seconds

    def check(self, request_path, workspace, inspect):
        folder = Path(request_path).parent
        response_path = folder / "bridge_response.json"
        deadline = time.monotonic() + self.timeout_seconds
        handled = set()
        while time.monotonic() < deadline:
            for path in sorted(folder.glob("inspect-*.request.json")):
                if path.name in handled:
                    continue
                handled.add(path.name)
                result_path = path.with_name(path.name.replace(".request.json", ".response.json"))
                try:
                    diagnostic = json.loads(path.read_text(encoding="utf-8"))
                    observation = inspect(diagnostic["workspace"])
                    result = {"status": "ok", "observation": observation}
                except Exception as exc:
                    result = {"status": "error", "error": f"{type(exc).__name__}: {exc}"}
                temporary = result_path.with_suffix(result_path.suffix + ".tmp")
                temporary.write_text(json.dumps(result, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
                temporary.replace(result_path)
            if response_path.is_file():
                response = json.loads(response_path.read_text(encoding="utf-8"))
                if response.get("status") != "ok":
                    raise RuntimeError(response.get("error", "Remote Agent bridge failed"))
                return response.get("message", "")
            time.sleep(self.poll_seconds)
        cancelled = folder / "bridge_cancelled.json"
        cancelled.write_text("{\"reason\":\"sampling-side timeout\"}\n", encoding="utf-8")
        raise TimeoutError(f"Agent bridge did not respond within {self.timeout_seconds} seconds")
