"""A decision pauses sampling; the agent may rerun inspect repeatedly before returning."""
import copy
import time
from pathlib import Path

from .programs import Programs
from .report import write_json


class AgentSession:
    def __init__(self, backend, run_dir, save_context):
        self.backend = backend
        self.root = Path(run_dir).resolve()
        self.save_context = save_context
        self.count = 0
        self.seconds = 0.0

    def check(self, ctx, observation, programs):
        self.count += 1
        folder = self.root / "decisions" / f"{self.count:05d}"
        folder.mkdir(parents=True)
        state = folder / "state.pt"
        self.save_context(ctx, state)
        request = folder / "request.json"
        diagnostic_workspace = folder / "diagnostic_workspace"
        write_json(request, {
            "session_id": self.root.name, "decision": self.count,
            "step": ctx.step, "nfe": ctx.nfe, "sigma": ctx.sigma,
            "state": str(state), "workspace": str(programs.workspace.resolve()),
            "diagnostic_workspace": str(diagnostic_workspace.resolve()),
            "policy_version": programs.version, "observation": observation,
            "instructions": str((Path(__file__).parent / "prompts/sampling_agent.md").resolve()),
            "inspect_command": ["reactive-samplers", "inspect", str(state), "--workspace", str(programs.workspace.resolve())],
            "feedback": str(self.root / "feedback.json"),
        })
        started = time.perf_counter()
        try:
            def inspect(candidate_workspace):
                candidate = Path(candidate_workspace).resolve()
                if candidate != diagnostic_workspace.resolve():
                    raise ValueError("Diagnostic workspace must be this decision's isolated workspace")
                probe = Programs(candidate, folder / "diagnostic_programs")
                memory = copy.deepcopy(ctx.analysis_memory)
                return probe.analysis.analyze(ctx, memory)

            if hasattr(self.backend, "check"):
                answer = self.backend.check(request, programs.workspace.resolve(), inspect)
            else:
                answer = self.backend(request, programs.workspace.resolve())
            (folder / "answer.txt").write_text(answer or "", encoding="utf-8")
        finally:
            elapsed = time.perf_counter() - started
            self.seconds += elapsed
            write_json(folder / "timing.json", {"seconds": elapsed})
